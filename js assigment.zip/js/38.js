function describe_city(city ,contry){
console.log(` ${city} is in ${contry}`);
}
let contry="pakistan";
let city="Islamabad";

describe_city( "karachi", "pakistan");
describe_city( city, contry);
describe_city( "jaddah", "suadia");