let msg="Hello Eric, would you like to learn some Python today?";
document.write(msg);