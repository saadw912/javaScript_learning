let Pizzas=["vigitable","chines","chicken"];
for(let i=0;i<Pizzas.length;i++){
    console.log(`I like ${Pizzas[i]} pizza`);
}
console.log("how much you like pizza")
for(let i=0;i<Pizzas.length;i++)
{
    console.log(" I really love pizza!"); 
}