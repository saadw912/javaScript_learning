
function sandwich_item(){
if (arguments==0)
{
    console.log("no item passed")
}
else 
{
    console.log("item are");
    for(let i=0;i<arguments.length;i++)
    {
        console.log(arguments[i]);
    }
}
}

sandwich_item("chicken","vagitable");