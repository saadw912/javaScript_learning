let favorite_fruits=["apple","pech","orange"];
for(let i=0;i<favorite_fruits.length;i++)
{
    if(favorite_fruits[i]=="apple")
    {
        console.log('you like apple');
    }
   else if(favorite_fruits[i]=="pech")
    {
        console.log('you like pech');
    }
   else if(favorite_fruits[i]=="mango")
    {
        console.log('you like mango');
    }
   else if(favorite_fruits[i]=="orange")
    {
        console.log('you like orange');
    }
   else if(favorite_fruits[i]=="grapes")
    {
        console.log('you like grapes');
    }

}
