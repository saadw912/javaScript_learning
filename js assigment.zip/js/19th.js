let GuestList=['mahaz','qasim','waleed'];
let alpha=[];
let revrs=[];
for(let i=0;i<GuestList.length;i++)
{
alpha[i]=GuestList[i];
revrs[i]=GuestList[i];
}
for(let i=0;i<GuestList.length;i++)
{
   console.log(`I would like to invite to dinner ${GuestList[i]}`);
}
console.log('alphabetical order')
console.log(alpha.sort());
console.log('reverse order')
console.log(revrs.reverse());
console.log('rorignal order')
console.log(GuestList);
console.log('double reverse  order')
console.log(revrs.reverse());