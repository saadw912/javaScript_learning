






//Adding Comments:





//Guest List
let GuestList=['mahaz','qasim','waleed'];
for(let i=0;i<GuestList.length;i++)
{
    document.write(`I would like to invite to dinner ${GuestList[i]}` +"<br>");
}
document.write(`I would not invite to  ${GuestList[0]} ` +"<br>");
var index = GuestList.indexOf('mahaz');

if (index !== -1) {
    GuestList[index] = "badar";
}
document.write("Print a second set of invitation messages");
document.write("<br>");
for(let i=0;i<GuestList.length;i++)
{
    document.write(`I would like to invite to dinner ${GuestList[i]}` +"<br>");
}
//More Guests
document.write("people that you found a bigger dinner table 'saeed','hamza','mujhid'.");
//Add one new guest to the beginning of your array
GuestList.unshift("saeed");
GuestList.push("mujhid");
console.log(GuestList);
// Add one new guest to the middle of your array
let start = GuestList.length/2;
GuestList.splice(start, 0, 'hamza');
console.log(GuestList);
for(let i=0;i<GuestList.length;i++)
{
    console.log(`I would like to invite to dinner ${GuestList[i]}`);
}