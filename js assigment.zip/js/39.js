function city_country(city ,contry){
    console.log(`"${city}", "${contry}"`);
    }
    city_country("Lahore","pakistan");
    city_country("istambol","Turki");
    city_country("sharja","UAE");