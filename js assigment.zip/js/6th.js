//Stripping Names:
let StrippingName=" saad \n waheed  \t abbasiii  ";
let trimStr = StrippingName.replace(/\s+/g, ' ');
document.write(trimStr);
document.write("<br>");