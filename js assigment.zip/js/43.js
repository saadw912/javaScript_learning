var  magicians_names = [ 'saad', 'badar', 'maaz' ]; 
let magicians_names2=[];
for(let i=0;i<magicians_names.length;i++)
{
     magicians_names2[i]= magicians_names[i]

}


function show_magicians(params) {
  for (i=0; i<params.length; i++) {
    console.log(`Great ${params[i]}`)
  }
}
show_magicians(magicians_names);
show_magicians(magicians_names2);