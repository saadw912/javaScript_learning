//Names
let friendName=['usman','ahmed','khurram','mujhid'];
document.write("friends Name by accessing each element in the list");
document.write("<br>");
document.write(`${friendName[0]} `);
document.write(`${friendName[1]} `);
document.write(`${friendName[2]} `);
document.write(`${friendName[3]} `);
document.write("<br>");