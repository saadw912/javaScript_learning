let mountains=['k2','koyo','laila peak','istro-e-nail'];
let rivers=['indus','jhelum','ravi','sawat','kunhar'];
let countries=['canada','japan','germany','england'];
let cities=['islamabad','rawat','abbottbad','faislabad','lahore','karachi'];
//21
let student_objt={
    mountains:"k2",
    rivers:"indus",
    countries:"pakistan",
    cities:"Karachi",
}

// console.log(student_objt.cities);
//22
//index error
// console.log(mountains[7]);
//23
let car = 'subaru';
console.log(car== 'subaru');
console.log(car==="subaru");
console.log(car==='subaru');
console.log(car==`subaru`);
console.log(car===`subaru`);
console.log(car=="subar");
console.log(car==`subar`);
console.log(car==`subarU`);
console.log(car==`Subaru`);
console.log(car==`Subaru `);
//24
console.log("24");
let str="saad";
let nmbr=14;
let fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(str==='saad');
console.log(str=="Saad");
console.log(nmbr==="14");
console.log(nmbr>14);
console.log(nmbr<10);
console.log(nmbr<=10);
console.log(nmbr>=10);
console.log("an item is in a array");
console.log(`${fruits.includes('Mango')}`);
console.log(`${fruits.includes('peach')}`);







