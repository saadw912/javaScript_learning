function make_shirt(){
    console.log(`I love JavaScript. Make a large shirt and a medium shirt with the default message, and a shirt of any size with a different message.`);
}
make_shirt();