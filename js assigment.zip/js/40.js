function make_album(artist_name,album_title,track=0){
let information={
    artist_Name:artist_name,
    album_Title:album_title
}
if(track==0)
{
    return 0;
}
else{
    return 
}
}
make_album("saad","test");