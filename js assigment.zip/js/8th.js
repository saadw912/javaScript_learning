document.write("<hr>");
document.write(`console.log(5 + 3)`);
document.write("<hr>");