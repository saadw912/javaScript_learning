let GuestList=['saeed', 'badar', 'hamza', 'qasim', 'waleed', 'mujhid']
document
document.write(`new dinner table won’t arrive in time for the dinner, and i have space for only two guests. <br>`)
document.write(`i can invite only two people for dinner.<br>`)
console.log(GuestList.length);
//Remove guests from your list one at a time until only two names remain in your list
for(let i=0;i<(GuestList.length-2);i++)
{
    //Each time you pop a name from your list, print a message to that person letting them know you’re sorry you can’t invite them to dinner.
    document.write(`${GuestList[i]} sorry you can’t invite them to dinner <br>`);
    GuestList[i]=null;
}
//remove null item in array
GuestList = GuestList.filter((a) => a);

for(let i=0;i<GuestList.length;i++)
{
    // Print a message to each of the two people still on your list, letting them know they’re still invited.
document.write(`${GuestList[i]} you're still invited.<br>`);
}
//Remove the last two names from your list, so you have an empty list
for(let i=0;i<(GuestList.length);i++)
{ 
    GuestList[i]=null;
}
GuestList = GuestList.filter((a) => a);
console.log(GuestList);