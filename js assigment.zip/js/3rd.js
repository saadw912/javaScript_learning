let name="Saad wahEEd abbASi";
document.write(name);
document.write("<br>");
document.write(`uppercase: ${name.toUpperCase()}<br>`);
document.write(`Lowercase: ${name.toLowerCase()}<br>`);
let lowercaseName=name.toLowerCase();
let namesplit=lowercaseName.split(" ");

for(let i=0;i<namesplit.length;i++)
{
    namesplit[i]=namesplit[i].charAt(0).toUpperCase() + namesplit[i].slice(1);
}
let titlecase= namesplit.join(" ");
document.write(`titlecase ${titlecase}<br>`);