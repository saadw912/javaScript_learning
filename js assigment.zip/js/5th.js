document.write(`Albert Einstein once said, “A person who never made a mistake never tried anything new.”`);
let famous_person=`Albert Einstein once said, “A person who never made a mistake never tried anything new.”`;
let message=famous_person;
document.write("<br>");
document.write(message);
document.write("<br>");