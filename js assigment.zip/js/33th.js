let Ordinal =[1,2,3,4,5,6,7,8,9];
for(let i=0;i<Ordinal.length;i++)
{
    document.write(`${Ordinal[i]}th`);
    document.write("<br>");

}