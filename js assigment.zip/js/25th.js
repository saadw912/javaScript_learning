let alien_color ="green";
if(alien_color=="green")
{
console.log("You just earned 5 points");
}
if(alien_color=="green")
{
console.log("You just earned 5 points");
if(alien_color=="red")
{

}
}
//26
