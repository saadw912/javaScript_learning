//Greetings
for(let i=0;i<friendName.length;i++)
{
    document.write(`Greetings ${friendName[i]} `); 
}
document.write("<br>");