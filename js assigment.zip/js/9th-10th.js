//Favorite Number
let FavNum=7;
console.log(`my favorite number is ${FavNum}`);