//Your Own Array
let transportation=['honda','yahama','suzuki'];
document.write(`I would like to own a ${transportation[0]}  motorcycle. `)
document.write(`I would like to own a ${transportation[1]}  motorcycle. `)
document.write(`I would like to own a ${transportation[2]}  motorcycle. `)
document.write("<br>");