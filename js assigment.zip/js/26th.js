let alien_color ="green";
if(alien_color=="gree")
{
    console.log("you earned 5 points for shooting the alien");
}
else
{
    console.log("you earned 10 points.");
}
