let current_users=["badar","saad","maaz","ahmed","adeel"];
let new_users=["waleed","hamza","saad","adeel","mujhid"];
for(let i=0;i<new_users.length;i++)
{
    if(new_users.includes(current_users[i]))
    {
        console.log(`"${new_users[i]}" the person will need to enter a new username`);
    }
    else
    {
        console.log(`"${new_users[i]}" the username is available`);
    }
}