let places=['islamabad','rwl','abbottbad','lahore','peshwar'];
console.log(places);
let alpha=[];
let revrs=[];
for(let i=0;i<places.length;i++)
{
alpha[i]=places[i];
revrs[i]=places[i];
}
console.log(alpha.sort());
console.log(places);
console.log(revrs.reverse());
console.log(places);
console.log(revrs.reverse());