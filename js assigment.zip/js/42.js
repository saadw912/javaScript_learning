var  magicians_names = [ 'saad', 'badar', 'maaz' ]; 

function show_magicians(params) {
  for (i=0; i<params.length; i++) {
    console.log(`Great ${params[i]}`)
  }
}
show_magicians(magicians_names);