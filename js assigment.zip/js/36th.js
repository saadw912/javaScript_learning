
function make_shirt(size){
console.log(`the size of the shirt = ${size}`);
}
make_shirt(6);