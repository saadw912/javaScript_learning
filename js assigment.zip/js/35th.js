let animals=["dog","cat","tiger"];
for(let i=0;i<animals.length;i++){
    console.log(`${animals[i]}`)
}
for(let i=0;i<animals.length;i++){

    console.log(`A ${animals[i]} would make a great pet`);
}
console.log(`A ${animals[1]} would make a great pet`);