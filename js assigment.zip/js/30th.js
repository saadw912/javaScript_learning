let usernam=["admin","saad","maaz","ahmed","adeel"];
let useremplty=[];
for(let i=0;i<usernam.length;i++)
{
    if(usernam[i]=="admin")
    {
        console.log("Hello admin, would you like to see a status report");
    }
    else
    {
        console.log("Hello Eric, thank you for logging in again");
    }
}
//31
if(usernam.length==0)
{
    console.log(`We need to find some users!`);
}
if(useremplty.length==0)
{
    console.log(`We need to find some users!`);
}